<!--- /footer-top ---->
<!---copy-right ---->
<div class="copy-right">
	<div class="container">
	
		<div class="footer-social-icons wow fadeInDown animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: fadeInDown;">
			<ul>
				<li><a class="button" href="https://www.facebook.com" method="get" target="_blank"><span>Facebook</span></a></li>
				<li><a class="twitter" href="https://www.twitter.com" method="get" target="_blank"><span>Twitter</span></a></li>
				<li><a class="flickr" href="https://www.instagram.com"><span>Instagram</span></a></li>
				<li><a class="googleplus" href="https://www.google.com" method="get" target="_blank"><span>Google+</span></a></li>
				<li><a class="dribbble" href="https://www.dribble.com" method="get" target="_blank"><span>Dribbble</span></a></li>
			</ul>
		</div>
		<p class="wow zoomIn animated animated" data-wow-delay=".5s" style="visibility: visible; animation-delay: 0.5s; animation-name: zoomIn;">© 2019 JATT TOURISM . All Rights Reserved by PUSHPINDER SINGH </p>
	</div>
</div>